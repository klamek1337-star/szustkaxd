package pl.szustka.szustkamod;

import net.fabricmc.api.ClientModInitializer;

public class SzustkaMod implements ClientModInitializer {
    public static final String MOD_ID = "szustkamod";

    @Override
    public void onInitializeClient() {
        FriendManager.load(); // wczytaj zapisaną listę friendsów
    }
}
