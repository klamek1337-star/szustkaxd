package pl.szustka.szustkamod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Lista friendsów. Zapisuje się automatycznie przy każdej zmianie
 * w config/szustkamod/friends.json i wczytuje przy starcie gry.
 */
public final class FriendManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path DIR = FabricLoader.getInstance().getConfigDir().resolve("szustkamod");
    private static final Path FILE = DIR.resolve("friends.json");
    private static final Set<String> FRIENDS = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

    private FriendManager() {}

    public static synchronized void load() {
        FRIENDS.clear();
        if (!Files.exists(FILE)) return;
        try (Reader reader = Files.newBufferedReader(FILE)) {
            List<String> list = GSON.fromJson(reader, new TypeToken<List<String>>() {}.getType());
            if (list != null) FRIENDS.addAll(list);
        } catch (Exception e) {
            System.err.println("[SzustkaMod] Nie udało się wczytać listy friendsów: " + e);
        }
    }

    private static void save() {
        try {
            Files.createDirectories(DIR);
            Path tmp = DIR.resolve("friends.json.tmp");
            try (Writer writer = Files.newBufferedWriter(tmp)) {
                GSON.toJson(new ArrayList<>(FRIENDS), writer);
            }
            Files.move(tmp, FILE, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            System.err.println("[SzustkaMod] Nie udało się zapisać listy friendsów: " + e);
        }
    }

    public static synchronized boolean add(String name) {
        boolean added = FRIENDS.add(name);
        if (added) save();
        return added;
    }

    public static synchronized boolean remove(String name) {
        boolean removed = FRIENDS.remove(name);
        if (removed) save();
        return removed;
    }

    public static synchronized boolean isFriend(String name) {
        return name != null && FRIENDS.contains(name);
    }

    public static synchronized List<String> getAll() {
        return new ArrayList<>(FRIENDS);
    }
}
