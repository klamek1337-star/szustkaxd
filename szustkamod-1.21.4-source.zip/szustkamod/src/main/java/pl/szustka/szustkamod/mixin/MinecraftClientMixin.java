package pl.szustka.szustkamod.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.szustka.szustkamod.screen.MainScreen;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Unique
    private boolean szustkamod$uWasDown = false;

    /** Co tick sprawdzamy klawisz U (działa bez Fabric API). Menu otwiera się tylko w grze, bez otwartego GUI. */
    @Inject(method = "tick", at = @At("TAIL"))
    private void szustkamod$tick(CallbackInfo ci) {
        MinecraftClient mc = (MinecraftClient) (Object) this;
        boolean down = mc.currentScreen == null
                && mc.player != null
                && mc.getWindow() != null
                && InputUtil.isKeyPressed(mc.getWindow().getHandle(), GLFW.GLFW_KEY_U);
        if (down && !szustkamod$uWasDown) {
            mc.setScreen(new MainScreen(null));
        }
        szustkamod$uWasDown = down;
    }
}
