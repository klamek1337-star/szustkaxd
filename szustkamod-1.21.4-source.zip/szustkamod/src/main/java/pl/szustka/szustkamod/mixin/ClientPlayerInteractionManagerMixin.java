package pl.szustka.szustkamod.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.szustka.szustkamod.FriendManager;

@Mixin(ClientPlayerInteractionManager.class)
public class ClientPlayerInteractionManagerMixin {

    /** Jeśli celem ataku jest friend - atak nie jest wysyłany, więc nie zadaje obrażeń. */
    @Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
    private void szustkamod$blockFriendAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
        if (target instanceof PlayerEntity other
                && FriendManager.isFriend(other.getName().getString())) {
            ci.cancel();
        }
    }
}
