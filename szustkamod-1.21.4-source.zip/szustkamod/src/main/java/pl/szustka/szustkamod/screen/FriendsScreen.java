package pl.szustka.szustkamod.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import pl.szustka.szustkamod.FriendManager;

import java.util.ArrayList;
import java.util.List;

/** Lista friendsów z możliwością usuwania + przycisk Add Friend. */
public class FriendsScreen extends Screen {
    private static final int ROW = 24;

    private final Screen parent;
    private int page;
    private int pageCount = 1;
    private final List<String> visible = new ArrayList<>();

    public FriendsScreen(Screen parent, int page) {
        super(Text.literal("Friends"));
        this.parent = parent;
        this.page = page;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        List<String> all = FriendManager.getAll();

        int perPage = Math.max(1, (this.height - 104) / ROW);
        pageCount = Math.max(1, (all.size() + perPage - 1) / perPage);
        page = Math.max(0, Math.min(page, pageCount - 1));

        int start = page * perPage;
        int end = Math.min(all.size(), start + perPage);
        visible.clear();
        visible.addAll(all.subList(start, end));

        for (int i = 0; i < visible.size(); i++) {
            final String name = visible.get(i);
            this.addDrawableChild(ButtonWidget.builder(Text.literal("Remove"), b -> {
                FriendManager.remove(name);
                this.client.setScreen(new FriendsScreen(parent, page));
            }).dimensions(cx + 40, 36 + i * ROW, 60, 20).build());
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Add Friend"),
                b -> this.client.setScreen(new AddFriendScreen(parent)))
                .dimensions(cx - 100, this.height - 52, 200, 20).build());

        ButtonWidget prev = ButtonWidget.builder(Text.literal("< Prev"),
                b -> this.client.setScreen(new FriendsScreen(parent, page - 1)))
                .dimensions(cx - 100, this.height - 28, 60, 20).build();
        prev.active = page > 0;
        this.addDrawableChild(prev);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> this.close())
                .dimensions(cx - 35, this.height - 28, 70, 20).build());

        ButtonWidget next = ButtonWidget.builder(Text.literal("Next >"),
                b -> this.client.setScreen(new FriendsScreen(parent, page + 1)))
                .dimensions(cx + 40, this.height - 28, 60, 20).build();
        next.active = page < pageCount - 1;
        this.addDrawableChild(next);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta); // tło + przyciski
        int cx = this.width / 2;

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 15, 0xFFFFFFFF);

        if (visible.isEmpty()) {
            context.drawCenteredTextWithShadow(this.textRenderer,
                    Text.literal("No friends yet. Click \"Add Friend\"."), cx, 60, 0xFFAAAAAA);
        }
        for (int i = 0; i < visible.size(); i++) {
            context.drawTextWithShadow(this.textRenderer, visible.get(i), cx - 100, 36 + i * ROW + 6, 0xFFFFFFFF);
        }

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("Page " + (page + 1) + "/" + pageCount), cx, this.height - 64, 0xFF888888);
    }

    @Override
    public void close() {
        this.client.setScreen(parent);
    }
}
