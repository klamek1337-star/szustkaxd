package pl.szustka.szustkamod.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import pl.szustka.szustkamod.FriendManager;

import java.util.ArrayList;
import java.util.List;

/** Dodawanie friendsa: wpisz nick albo kliknij gracza z listy online. */
public class AddFriendScreen extends Screen {
    private static final int LIST_START_Y = 126;

    private final Screen mainParent; // MainScreen - do niego wraca FriendsScreen
    private final Text status;
    private final int statusColor;
    private TextFieldWidget nameField;
    private final List<String> online = new ArrayList<>();

    public AddFriendScreen(Screen mainParent) {
        this(mainParent, Text.empty(), 0xFFFFFFFF);
    }

    private AddFriendScreen(Screen mainParent, Text status, int statusColor) {
        super(Text.literal("Add Friend"));
        this.mainParent = mainParent;
        this.status = status;
        this.statusColor = statusColor;
    }

    @Override
    protected void init() {
        int cx = this.width / 2;

        nameField = new TextFieldWidget(this.textRenderer, cx - 100, 50, 200, 20, Text.literal("Nickname"));
        nameField.setMaxLength(16);
        this.addDrawableChild(nameField);
        this.setInitialFocus(nameField);

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Add"), b -> tryAdd(nameField.getText()))
                .dimensions(cx - 100, 74, 200, 20).build());

        // Gracze aktualnie online (z listy TAB)
        online.clear();
        if (this.client.getNetworkHandler() != null) {
            String self = this.client.getSession().getUsername();
            for (PlayerListEntry entry : this.client.getNetworkHandler().getPlayerList()) {
                String n = entry.getProfile().getName();
                if (!n.equalsIgnoreCase(self) && !FriendManager.isFriend(n)) online.add(n);
            }
            online.sort(String.CASE_INSENSITIVE_ORDER);
        }
        int maxRows = Math.max(0, Math.min(online.size(), (this.height - 36 - LIST_START_Y) / 22));
        for (int i = 0; i < maxRows; i++) {
            final String n = online.get(i);
            this.addDrawableChild(ButtonWidget.builder(Text.literal("+ " + n), b -> tryAdd(n))
                    .dimensions(cx - 100, LIST_START_Y + i * 22, 200, 20).build());
        }

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> this.close())
                .dimensions(cx - 100, this.height - 28, 200, 20).build());
    }

    private void tryAdd(String raw) {
        String name = raw == null ? "" : raw.trim();
        if (!name.matches("[A-Za-z0-9_]{3,16}")) {
            this.client.setScreen(new AddFriendScreen(mainParent,
                    Text.literal("Invalid nickname (3-16 chars: letters, digits, _)"), 0xFFFF5555));
            return;
        }
        if (FriendManager.add(name)) {
            this.client.setScreen(new AddFriendScreen(mainParent,
                    Text.literal("Added " + name + " to friends!"), 0xFF55FF55));
        } else {
            this.client.setScreen(new AddFriendScreen(mainParent,
                    Text.literal(name + " is already your friend."), 0xFFFFAA00));
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            tryAdd(nameField.getText());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta); // tło + przyciski + pole tekstowe
        int cx = this.width / 2;

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, cx, 15, 0xFFFFFFFF);
        context.drawTextWithShadow(this.textRenderer, "Nickname:", cx - 100, 38, 0xFFAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer, status, cx, 100, statusColor);
        if (!online.isEmpty()) {
            context.drawTextWithShadow(this.textRenderer, "Online players:", cx - 100, 113, 0xFFAAAAAA);
        }
    }

    @Override
    public void close() {
        this.client.setScreen(new FriendsScreen(mainParent, 0));
    }
}
