# SzustkaMod (Fabric 1.21.4)

Dodawaj graczy jako "friendsów" - Twoje uderzenia nie zadają im obrażeń.
Menu: **U -> Friends -> Add Friend**.

Wymaga tylko Fabric Loadera (>= 0.16) i Javy 21. NIE wymaga Fabric API.
Lista friendsów zapisuje się sama w `.minecraft/config/szustkamod/friends.json`.

## Budowanie lokalnie
1. JDK 21 + Gradle 8.11+
2. `gradle build`
3. Gotowy plik: `build/libs/szustkamod-1.0.0.jar` -> wrzuć do `.minecraft/mods`

## Budowanie bez instalowania czegokolwiek
Wrzuć cały folder na GitHub -> zakładka Actions -> "build" -> Run workflow
-> po chwili pobierz artefakt `szustkamod` (zawiera gotowy .jar).
